local _, ns = ...

local dossierFrame
local selectedDossierKey = nil
local lastRenderedKey = nil
local activeSubView = "CHAR"
local lastRenderedSubView = nil
local SUB_VIEWS = { "CHAR", "ABOUT", "GLANCES", "NOTES" }

local CORE_STANDINGS = {
    { key = "None",       tone = nil,       colorHex = "ff9aa0a6" },
    { key = "Ally",       tone = "MINT",    colorHex = "ff81c995" },
    { key = "Friendly",   tone = "MINT",    colorHex = "ff81c995" },
    { key = "Neutral",    tone = "PRIMARY", colorHex = "ff8ab4f8" },
    { key = "Unfriendly", tone = "CORAL",   colorHex = "fff28b82" },
    { key = "Rival",      tone = "CORAL",   colorHex = "fff28b82" },
    { key = "Marked",     tone = "AMBER",   colorHex = "fffdd663" },
}

local function NormalizeKey(k)
    return string.lower(strtrim(tostring(k or "")))
end

local function StripColorCodes(str)
    if not str then return "" end
    local clean = string.gsub(tostring(str), "|c%x%x%x%x%x%x%x%x", "")
    clean = string.gsub(clean, "|r", "")
    return clean
end

local function ResolveProfileRecordForKey(key)
    if not key or key == "" then return nil end
    if ns.mspCache and type(ns.mspCache) == "table" then
        if type(ns.mspCache[key]) == "table" then
            return ns.mspCache[key]
        end
        local norm = NormalizeKey(key)
        for cacheKey, rec in pairs(ns.mspCache) do
            if type(rec) == "table" and NormalizeKey(cacheKey) == norm then
                return rec
            end
        end
    end
    if ns.GetCachedMSP then
        local ok, rec = pcall(ns.GetCachedMSP, ns, key)
        if ok and type(rec) == "table" then
            return rec
        end
    end
    return nil
end

local function SanitizeStandingsData()
    ns.db = ns.db or {}
    if type(ns.db.customStandings) == "table" then
        local cleaned = {}
        for _, item in ipairs(ns.db.customStandings) do
            local lbl = type(item) == "table" and item.label or item
            local sLbl = lbl and strtrim(tostring(lbl)) or ""
            if sLbl ~= "" and string.lower(sLbl) ~= "fool" then
                local tone = (type(item) == "table" and item.tone) or "AMBER"
                table.insert(cleaned, { label = sLbl, tone = tone })
            end
        end
        ns.db.customStandings = cleaned
    end
    if type(ns.db.notes) == "table" then
        for _, rec in pairs(ns.db.notes) do
            if type(rec) == "table" and rec.standing and string.lower(tostring(rec.standing)) == "fool" then
                rec.standing = "None"
            end
        end
    end
end

local function GetAllStandingsList()
    SanitizeStandingsData()
    local list = {}
    local seen = {}
    for _, item in ipairs(CORE_STANDINGS) do
        table.insert(list, item.key)
        seen[string.lower(item.key)] = true
    end
    for _, item in ipairs((ns.db and ns.db.customStandings) or {}) do
        local lbl = type(item) == "table" and item.label or item
        if lbl and strtrim(tostring(lbl)) ~= "" then
            local clean = strtrim(tostring(lbl))
            local lk = string.lower(clean)
            if not seen[lk] then
                seen[lk] = true
                table.insert(list, clean)
            end
        end
    end
    return list
end

function ns:GetStandingTone(standingName)
    if not standingName or standingName == "None" then return nil end
    for _, item in ipairs(CORE_STANDINGS) do
        if string.lower(item.key) == string.lower(tostring(standingName)) then
            return item.tone
        end
    end
    for _, item in ipairs((ns.db and ns.db.customStandings) or {}) do
        if type(item) == "table" and string.lower(tostring(item.label or "")) == string.lower(tostring(standingName)) then
            return item.tone or "AMBER"
        end
    end
    return "AMBER"
end

function ns:GetStandingColorHex(standingName)
    if not standingName or standingName == "None" then return "ff9aa0a6" end
    for _, item in ipairs(CORE_STANDINGS) do
        if string.lower(item.key) == string.lower(tostring(standingName)) then
            return item.colorHex or "fffdd663"
        end
    end
    local tone = ns:GetStandingTone(standingName)
    if tone == "MINT" then return "ff81c995"
    elseif tone == "PRIMARY" then return "ff8ab4f8"
    elseif tone == "CORAL" then return "fff28b82"
    end
    return "fffdd663"
end

function ns:AddCustomStanding(label, tone)
    local clean = strtrim(tostring(label or ""))
    if clean == "" or string.lower(clean) == "fool" then return nil end
    ns.db = ns.db or {}
    ns.db.customStandings = ns.db.customStandings or {}
    for _, item in ipairs(ns.db.customStandings) do
        if type(item) == "table" and string.lower(tostring(item.label or "")) == string.lower(clean) then
            if tone then item.tone = tone end
            return clean
        end
    end
    table.insert(ns.db.customStandings, { label = clean, tone = tone or "AMBER" })
    return clean
end

local function EnsureNoteRecord(key)
    SanitizeStandingsData()
    ns.db.notes = ns.db.notes or {}
    local rec = ns.db.notes[key]
    if type(rec) ~= "table" then
        rec = { standing = "None", accountNote = "", charNotes = {}, charRelationships = {}, customRelationship = "" }
        ns.db.notes[key] = rec
    end
    rec.standing = rec.standing or "None"
    rec.charNotes = rec.charNotes or {}
    rec.charRelationships = rec.charRelationships or {}
    rec.customRelationship = rec.customRelationship or ""
    if rec.accountNote == nil then
        rec.accountNote = rec.note or ""
    end
    return rec
end

function ns:GetAssignedRelationship(key)
    if not key or not ns.db or not ns.db.notes then return "" end
    local rec = ns.db.notes[key]
    if type(rec) ~= "table" then return "" end
    local charKey = ns.GetPlayerCharKey and ns:GetPlayerCharKey() or "Default"
    local cRel = type(rec.charRelationships) == "table" and strtrim(tostring(rec.charRelationships[charKey] or "")) or ""
    if cRel ~= "" then return cRel end
    return strtrim(tostring(rec.customRelationship or ""))
end

local function SaveCurrentNotes()
    if not dossierFrame or not selectedDossierKey then return end
    local rec = EnsureNoteRecord(selectedDossierKey)
    local charKey = ns:GetPlayerCharKey()
    local charTxt = dossierFrame.charNoteBox:GetText() or ""
    local acctTxt = dossierFrame.acctNoteBox:GetText() or ""
    local relTxt = strtrim(dossierFrame.relEditBox and dossierFrame.relEditBox:GetText() or "")

    rec.charNotes[charKey] = charTxt
    rec.accountNote = acctTxt
    rec.note = acctTxt
    rec.charRelationships[charKey] = relTxt
    rec.customRelationship = relTxt

    dossierFrame.charNoteBox.isDirty = false
    dossierFrame.acctNoteBox.isDirty = false
    if dossierFrame.relEditBox then
        dossierFrame.relEditBox.isDirty = false
    end

    if ns.RefreshTargetHUD then ns:RefreshTargetHUD() end
    if ns.RefreshAllNameplates then ns:RefreshAllNameplates() end
    if ns.mainFrame and ns.mainFrame:IsShown() and ns.RefreshTargetCard then
        ns:RefreshTargetCard()
    end
end

local function ApplyStandingSelection(standingName)
    if not dossierFrame or not selectedDossierKey then return end
    local rec = EnsureNoteRecord(selectedDossierKey)
    rec.standing = standingName or "None"
    if dossierFrame.standingDropdown then
        dossierFrame.standingDropdown:Hide()
    end
    ns:RefreshDossierWindow()
    ns:RefreshTargetHUD()
    if ns.RefreshAllNameplates then ns:RefreshAllNameplates() end
    if ns.mainFrame and ns.mainFrame:IsShown() and ns.RefreshTargetCard then
        ns:RefreshTargetCard()
    end
    if dossierFrame.standingBtn and dossierFrame.standingBtn:IsVisible() and ns.SetControllerFocus then
        ns:SetControllerFocus(dossierFrame.standingBtn)
    end
end

local function IsPlayerSelfKey(key)
    if not key or key == "" then return false end
    local lk = NormalizeKey(key)
    local pName = UnitName("player")
    if pName then
        local shortK = strsplit("-", key)
        if string.lower(strtrim(shortK or "")) == string.lower(pName) then
            return true
        end
    end
    if ns.GetUnitKey then
        local selfKey = ns:GetUnitKey("player")
        if selfKey and NormalizeKey(selfKey) == lk then
            return true
        end
    end
    if ns.profile then
        local parts = {}
        if ns.profile.firstName and strtrim(ns.profile.firstName) ~= "" then
            table.insert(parts, strtrim(ns.profile.firstName))
        end
        if ns.profile.lastName and strtrim(ns.profile.lastName) ~= "" then
            table.insert(parts, strtrim(ns.profile.lastName))
        end
        if #parts > 0 and string.lower(table.concat(parts, " ")) == lk then
            return true
        end
    end
    return false
end

local function GetRealCharacterName(key, isSelf)
    if isSelf and UnitName then
        local uName = UnitName("player")
        if uName and strtrim(uName) ~= "" then
            return strtrim(uName)
        end
    end
    local base = strsplit("-", tostring(key or ""))
    return strtrim(tostring(base or ""))
end

local function IsSentinelOrInvalidIconID(numId)
    if type(numId) ~= "number" or numId <= 0 then
        return true
    end
    if numId >= 2147483647 then
        return true
    end
    return false
end

local function ResolveDossierIconValue(iconVal)
    if iconVal == nil or iconVal == false then return nil end
    local clean = strtrim(tostring(iconVal))
    local lower = string.lower(clean)
    if clean == "" or lower == "nil" or lower == "none" or lower == "0" then
        return nil
    end

    local directNum = tonumber(clean)
    if directNum and IsSentinelOrInvalidIconID(directNum) then
        return nil
    end

    if ns.ResolveIconTexture then
        local resolved = ns:ResolveIconTexture(clean, nil)
        if type(resolved) == "number" then
            if IsSentinelOrInvalidIconID(resolved) then
                return nil
            end
            return resolved
        elseif type(resolved) == "string" then
            local rClean = strtrim(resolved)
            local rLower = string.lower(rClean)
            if rClean ~= "" and rLower ~= "nil" and rLower ~= "none" and rLower ~= "0" then
                local rNum = tonumber(rClean)
                if not rNum or not IsSentinelOrInvalidIconID(rNum) then
                    return rClean
                end
            end
        end
    end

    if directNum and not IsSentinelOrInvalidIconID(directNum) then
        return directNum
    end

    return string.find(clean, "\\", 1, true) and clean or ("Interface\\Icons\\" .. clean)
end

local function ResolveClassFileToken(rawClass, key, isSelf, isLiveTarget)
    if isSelf and UnitClass then
        local _, pClass = UnitClass("player")
        if pClass and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[pClass] then
            return pClass
        end
    end
    if isLiveTarget and UnitClass then
        local _, tClass = UnitClass("target")
        if tClass and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[tClass] then
            return tClass
        end
    end

    local plainClass = strtrim(StripColorCodes(tostring(rawClass or "")))
    local cleaned = string.upper(plainClass)
    if cleaned ~= "" and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[cleaned] then
        return cleaned
    end

    local nameToToken = {
        ["WARRIOR"]      = "WARRIOR",
        ["PALADIN"]      = "PALADIN",
        ["HUNTER"]       = "HUNTER",
        ["ROGUE"]        = "ROGUE",
        ["PRIEST"]       = "PRIEST",
        ["DEATH KNIGHT"] = "DEATHKNIGHT",
        ["DEATHKNIGHT"]  = "DEATHKNIGHT",
        ["SHAMAN"]       = "SHAMAN",
        ["MAGE"]         = "MAGE",
        ["WARLOCK"]      = "WARLOCK",
        ["MONK"]         = "MONK",
        ["DRUID"]        = "DRUID",
        ["DEMON HUNTER"] = "DEMONHUNTER",
        ["DEMONHUNTER"]  = "DEMONHUNTER",
        ["EVOKER"]       = "EVOKER",
    }

    if type(LOCALIZED_CLASS_NAMES_MALE) == "table" then
        for token, locName in pairs(LOCALIZED_CLASS_NAMES_MALE) do
            if type(locName) == "string" and string.lower(locName) == string.lower(plainClass) then
                nameToToken[string.upper(locName)] = token
            end
        end
    end
    if type(LOCALIZED_CLASS_NAMES_FEMALE) == "table" then
        for token, locName in pairs(LOCALIZED_CLASS_NAMES_FEMALE) do
            if type(locName) == "string" and string.lower(locName) == string.lower(plainClass) then
                nameToToken[string.upper(locName)] = token
            end
        end
    end

    local mapped = nameToToken[cleaned]
    if mapped and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[mapped] then
        return mapped
    end

    if key and UnitExists and UnitIsPlayer then
        local shortName = strsplit("-", tostring(key))
        if shortName and UnitExists(shortName) and UnitIsPlayer(shortName) and UnitClass then
            local _, uClass = UnitClass(shortName)
            if uClass and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[uClass] then
                return uClass
            end
        end
    end

    return nil
end

local function ReanchorDossierHeader(hasIcon)
    if not dossierFrame then return end
    local leftX = hasIcon and 78 or 18
    dossierFrame.modeBadge:ClearAllPoints()
    dossierFrame.modeBadge:SetPoint("TOPLEFT", dossierFrame, "TOPLEFT", leftX, -10)

    dossierFrame.headerName:ClearAllPoints()
    dossierFrame.headerName:SetPoint("TOPLEFT", dossierFrame, "TOPLEFT", leftX, -25)
    if dossierFrame.closeBtn then
        dossierFrame.headerName:SetPoint("RIGHT", dossierFrame.closeBtn, "LEFT", -12, 0)
    else
        dossierFrame.headerName:SetPoint("TOPRIGHT", dossierFrame, "TOPRIGHT", -48, -25)
    end

    dossierFrame.vitalsText:ClearAllPoints()
    dossierFrame.vitalsText:SetPoint("TOPLEFT", dossierFrame, "TOPLEFT", leftX, -50)
    dossierFrame.vitalsText:SetPoint("TOPRIGHT", dossierFrame, "TOPRIGHT", -16, -50)
end

local function HideDossierPortrait()
    if not dossierFrame then return end
    if dossierFrame.portraitTex then
        dossierFrame.portraitTex:SetTexture(nil)
        dossierFrame.portraitTex:Hide()
    end
    if dossierFrame.portraitBox then
        dossierFrame.portraitBox:Hide()
    end
    ReanchorDossierHeader(false)
end

local function SetDossierPortraitIcon(iconVal, classToken, hasRPProfile)
    if not dossierFrame or not dossierFrame.portraitBox or not dossierFrame.portraitTex then return end
    dossierFrame.portraitTex:SetTexture(nil)

    local texVal = ResolveDossierIconValue(iconVal)
    if texVal then
        dossierFrame.portraitTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        local ok = pcall(function()
            dossierFrame.portraitTex:SetTexture(texVal)
        end)

        local appliedTex = ok and dossierFrame.portraitTex:GetTexture()
        if appliedTex and appliedTex ~= "" and appliedTex ~= 0 then
            dossierFrame.portraitBox:Show()
            dossierFrame.portraitTex:Show()
            ReanchorDossierHeader(true)
            return
        end
    end

    local coords = classToken and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[classToken]
    if coords then
        dossierFrame.portraitTex:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
        dossierFrame.portraitTex:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
        if dossierFrame.portraitTex:GetTexture() then
            dossierFrame.portraitBox:Show()
            dossierFrame.portraitTex:Show()
            ReanchorDossierHeader(true)
            return
        end
    end

    if hasRPProfile then
        local fallbackIcon = (ns.IconPool and ns.IconPool.defaultFallback) or 134400
        dossierFrame.portraitTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        local ok = pcall(function()
            dossierFrame.portraitTex:SetTexture(fallbackIcon)
        end)
        local appliedTex = ok and dossierFrame.portraitTex:GetTexture()
        if appliedTex and appliedTex ~= "" and appliedTex ~= 0 then
            dossierFrame.portraitBox:Show()
            dossierFrame.portraitTex:Show()
            ReanchorDossierHeader(true)
            return
        end
    end

    HideDossierPortrait()
end

local function CleanOOCDisplayText(raw)
    if not raw then return "" end
    local clean = strtrim(StripColorCodes(raw))
    clean = string.gsub(clean, "%[Walk%-Ups:[^%]]*%]", "")
    clean = string.gsub(clean, "%[Walk%-Ups Welcome%]", "")
    clean = string.gsub(clean, "%[Walk%-Ups: Ask First%]", "")
    clean = string.gsub(clean, "%[No Walk%-Ups%]", "")
    clean = string.gsub(clean, "%[Pronouns:[^%]]*%]", "")
    clean = string.gsub(clean, "^%s*[•|%-]+%s*", "")
    clean = string.gsub(clean, "%s*[•|%-]+%s*$", "")
    return strtrim(clean)
end

local function NormalizeHex6(raw)
    if type(raw) ~= "string" then return nil end
    local clean = string.gsub(strtrim(raw), "^#+", "")
    clean = string.gsub(clean, "^|[cC]", "")
    if string.match(clean, "^%x%x%x%x%x%x%x%x$") then
        clean = string.sub(clean, 3, 8)
    end
    if string.match(clean, "^%x%x%x%x%x%x$") then
        return string.lower(clean)
    end
    return nil
end

local function FormatRow(label, value, valueColorHex)
    if not value or strtrim(StripColorCodes(value)) == "" then return nil end
    local raw = strtrim(tostring(value))
    if valueColorHex and not string.find(raw, "|c", 1, true) then
        return string.format("|cff9aa0a6%s:|r  |c%s%s|r", label, valueColorHex, raw)
    end
    return string.format("|cff9aa0a6%s:|r  |cffe8eaed%s|r", label, raw)
end

local function ResolveRelationshipDisplay(rsVal, assignedRel)
    if assignedRel and strtrim(assignedRel) ~= "" then
        return "|cfffdd663" .. strtrim(assignedRel) .. "|r"
    end
    if not rsVal then return nil end
    local s = strtrim(StripColorCodes(tostring(rsVal)))
    if s == "" or s == "0" then return nil end
    if tonumber(s) and ns.GetRelationshipLabel then
        return ns:GetRelationshipLabel(s)
    end
    return s
end

local function BuildCharacteristicsText(data, isSelf, key)
    local lines = {}
    local basic = {}
    local classHex = (isSelf and ns.GetPlayerClassColorCode and ns:GetPlayerClassColorCode()) or nil
    local eyeHex = (isSelf and ns.profile and NormalizeHex6(ns.profile.eyeColorHex)) or nil
    local eyeColorCode = eyeHex and ("ff" .. eyeHex) or nil

    local function AddBasic(lbl, val, hex)
        local r = FormatRow(lbl, val, hex)
        if r then table.insert(basic, r) end
    end

    AddBasic("Race", data.RA)
    AddBasic("Class", StripColorCodes(data.RC or ""), classHex)
    AddBasic("Gender", data.GN or (isSelf and ns.profile and ns.profile.gender))
    AddBasic("Pronouns", data.PR or (isSelf and ns.profile and ns.profile.pronouns))
    AddBasic("Age", data.AG)
    AddBasic("Height", data.AH)
    AddBasic("Build / Body Shape", data.AW)
    AddBasic("Eye Color", StripColorCodes(data.AE or ""), eyeColorCode)
    AddBasic("Birthplace", data.HB)
    AddBasic("Residence", data.HH)

    local assignedRel = (not isSelf and key and ns:GetAssignedRelationship(key)) or ""
    local relText = ResolveRelationshipDisplay(data.RS, assignedRel)
    if relText then
        AddBasic("Relationship", relText)
    end
    if data.FR and data.FR ~= "" and data.FR ~= "0" then
        AddBasic("RP Proficiency", ns:GetRPStyleLabel(data.FR))
    end

    if #basic > 0 then
        table.insert(lines, "|cff8ab4f8BASIC INFORMATION|r\n" .. table.concat(basic, "\n"))
    end

    local extra = {}
    local function AddExtra(lbl, val)
        local r = FormatRow(lbl, val)
        if r then table.insert(extra, r) end
    end
    AddExtra("House / Clan", data.NH)
    AddExtra("Motto", data.MO)
    if isSelf and ns.profile then
        AddExtra("Facial Features", ns.profile.facialFeatures)
        AddExtra("Tattoos / Markings", ns.profile.tattoos)
        AddExtra("Voice Reference", ns.profile.voiceReference)
    end

    if #extra > 0 then
        table.insert(lines, "|cfffdd663ADDITIONAL INFORMATION|r\n" .. table.concat(extra, "\n"))
    end

    if isSelf and ns.profile then
        local styleLines = {}
        if type(ns.profile.rpStyleTopics) == "table" then
            local t = ns.profile.rpStyleTopics
            local function AddStyleRow(lbl, val)
                if val and val ~= "" and val ~= "Do not show" then
                    table.insert(styleLines, string.format("|cff9aa0a6%s:|r |cffe8eaed%s|r", lbl, val))
                end
            end
            AddStyleRow("Accept character injury", t.injury)
            AddStyleRow("Accept character death", t.death)
            AddStyleRow("Accept character romance", t.romance)
            AddStyleRow("Accept criminal activity", t.criminal)
            AddStyleRow("Accept loss of control", t.lossOfControl)
            if t.guild == "Yes" then
                local wowGuild = (GetGuildInfo and GetGuildInfo("player")) or ""
                AddStyleRow("Guild membership", wowGuild ~= "" and wowGuild or "Yes")
            elseif t.guild and t.guild ~= "" and t.guild ~= "Do not show" then
                AddStyleRow("Guild membership", t.guild)
            end
        end

        if #styleLines > 0 then
            table.insert(lines, "|cff8ab4f8ROLEPLAY STYLE|r\n" .. table.concat(styleLines, "\n"))
        end

        local oocLines = {}
        local oocRaw = ns.profile.oocNotes or ns.profile.oocInfo
        local oocOnly = CleanOOCDisplayText(oocRaw)
        if oocOnly ~= "" then
            table.insert(oocLines, oocOnly)
        end
        local lgbtqText = (ns.profile.lgbtqFriendly ~= false) and "|cff81c995Yes|r" or "|cff9aa0a6No|r"
        local erpText = ns.profile.erpFriendly and "|cfffdd663Yes|r" or "|cff9aa0a6No|r"
        local mdniText = ns.profile.mdni and "|cfff28b82Yes|r" or "|cff9aa0a6No|r"
        table.insert(oocLines, "|cff9aa0a6LGBTQIA2S+ friendly:|r " .. lgbtqText)
        table.insert(oocLines, "|cff9aa0a6ERP:|r " .. erpText)
        table.insert(oocLines, "|cff9aa0a6MDNI:|r " .. mdniText)
        table.insert(lines, "|cff81c995OTHER INFORMATION (OOC)|r\n" .. table.concat(oocLines, "\n"))
    elseif data.CO and CleanOOCDisplayText(data.CO) ~= "" then
        table.insert(lines, "|cff81c995OTHER INFORMATION (OOC)|r\n" .. CleanOOCDisplayText(data.CO))
    end

    local cuVal = (isSelf and ns.profile and ns.profile.currently) or data.CU
    if cuVal and strtrim(cuVal) ~= "" then
        table.insert(lines, "|cff81c995CURRENTLY|r\n" .. strtrim(cuVal))
    end

    if #lines == 0 then
        return "|cff9aa0a6No characteristics fields listed in this profile yet.|r"
    end
    return table.concat(lines, "\n\n")
end

local function BuildAboutText(data)
    local lines = {}
    if data.DE and strtrim(data.DE) ~= "" then
        table.insert(lines, "|cff8ab4f8PHYSICAL DESCRIPTION & PERSONALITY|r\n" .. data.DE)
    end
    if data.HI and strtrim(data.HI) ~= "" then
        table.insert(lines, "|cfffdd663CHARACTER HISTORY|r\n" .. data.HI)
    end
    if #lines == 0 then
        return "|cff9aa0a6No Physical Description or History written in this profile.|r"
    end
    return table.concat(lines, "\n\n")
end

local function BuildGlancesStatusText(data, isSelf)
    local lines = {}
    local structured = ns:ParseGlancesStructured(data.PE)
    if #structured > 0 then
        local gLines = {}
        for idx = 1, math.min(5, #structured) do
            local g = structured[idx]
            local iconTag = string.format("|T%s:22:22:0:0:64:64:4:60:4:60|t ", g.icon)
            if g.detail and g.detail ~= "" then
                table.insert(gLines, string.format("%s|cfffdd663%s|r\n%s", iconTag, g.title, g.detail))
            else
                table.insert(gLines, string.format("%s|cfffdd663%s|r", iconTag, g.title))
            end
        end
        table.insert(lines, "|cfffdd663AT FIRST GLANCE|r\n" .. table.concat(gLines, "\n\n"))
    end

    local cuVal = (isSelf and ns.profile and ns.profile.currently) or data.CU
    if cuVal and strtrim(cuVal) ~= "" then
        table.insert(lines, "|cff8ab4f8CURRENTLY|r\n" .. strtrim(cuVal))
    end

    if #lines == 0 then
        return "|cff9aa0a6No First Glances or Currently status listed in this profile.|r"
    end
    return table.concat(lines, "\n\n")
end

function ns:CycleDossierTab(delta)
    if not dossierFrame or not dossierFrame:IsShown() then return end
    if activeSubView == "NOTES" then SaveCurrentNotes() end
    if dossierFrame.standingDropdown then dossierFrame.standingDropdown:Hide() end
    local curIdx = 1
    for i, v in ipairs(SUB_VIEWS) do
        if v == activeSubView then curIdx = i break end
    end
    local nextIdx = ((curIdx - 1 + (delta or 1)) % #SUB_VIEWS) + 1
    activeSubView = SUB_VIEWS[nextIdx]
    ns:RefreshDossierWindow()
end

function ns:RefreshDossierWindow()
    if not dossierFrame or not dossierFrame:IsShown() then return end

    local key = selectedDossierKey
    if not key and UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then
        key = (ns.GetUnitKey and ns:GetUnitKey("target")) or UnitName("target")
    end
    key = key or ns.lastInspectedKey

    dossierFrame.tabChar:SetTone(activeSubView == "CHAR" and "PRIMARY" or nil)
    dossierFrame.tabAbout:SetTone(activeSubView == "ABOUT" and "PRIMARY" or nil)
    dossierFrame.tabGlances:SetTone(activeSubView == "GLANCES" and "PRIMARY" or nil)
    dossierFrame.tabNotes:SetTone(activeSubView == "NOTES" and "PRIMARY" or nil)

    if not key then
        SetDossierPortraitIcon(nil, nil, false)
        dossierFrame.modeBadge:SetText("|cff9aa0a6[NO PROFILE SELECTED]|r")
        dossierFrame.headerName:SetText("|cff9aa0a6Select a Player from Known RP or Target Someone|r")
        dossierFrame.vitalsText:SetText("")
        dossierFrame.readerBox:Show()
        dossierFrame.notesPanel:Hide()
        dossierFrame.scrollText:SetText("")
        return
    end

    local viewChanged = (key ~= lastRenderedKey) or (activeSubView ~= lastRenderedSubView)
    selectedDossierKey = key
    lastRenderedKey = key
    lastRenderedSubView = activeSubView

    local isSelf = IsPlayerSelfKey(key)
    local realCharName = GetRealCharacterName(key, isSelf)
    local isLiveTarget = UnitExists("target") and UnitIsPlayer("target") and ns.GetUnitKey and (ns:GetUnitKey("target") == key)
    local tHex = "ff8ab4f8"
    if isSelf and ns.GetPlayerClassColorCode then
        tHex = ns:GetPlayerClassColorCode()
    elseif isLiveTarget then
        local _, tClass = UnitClass("target")
        tHex = (tClass and RAID_CLASS_COLORS and RAID_CLASS_COLORS[tClass] and RAID_CLASS_COLORS[tClass].colorStr) or "ffffffff"
    end

    local topMetaParts = {}
    if isLiveTarget then
        table.insert(topMetaParts, "|cff81c995[LIVE TARGET]|r")
    end
    if realCharName ~= "" then
        table.insert(topMetaParts, "|cff9aa0a6(" .. realCharName .. ")|r")
    end
    dossierFrame.modeBadge:SetText(table.concat(topMetaParts, "  "))

    local data = ResolveProfileRecordForKey(key)
    local standing, charNote, acctNote, hasNote = ns:GetNoteInfo(key)
    local assignedRel = ns:GetAssignedRelationship(key)
    local hasRPProfile = (data and data.NA and data.NA ~= "") and true or false

    dossierFrame.tabNotes:SetText(hasNote and "Notes |cff81c995*|r" or "Notes")

    local activeIcon = (isSelf and ns.profile and ns.profile.icon) or (data and data.IC)
    local classToken = ResolveClassFileToken(data and data.RC, key, isSelf, isLiveTarget)
    SetDossierPortraitIcon(activeIcon, classToken, hasRPProfile)

    if not data or not data.NA then
        dossierFrame.headerName:SetText("|c" .. tHex .. (realCharName ~= "" and realCharName or key) .. "|r")
        if ns.IsScanPending and ns:IsScanPending(key) then
            dossierFrame.vitalsText:SetText("|cff8ab4f8Scanning LibMSP profile... Waiting for reply...|r")
        else
            dossierFrame.vitalsText:SetText("|cff9aa0a6No RP profile cached yet.|r")
        end
    else
        local displayName = data.NA
        local embeddedHex = type(displayName) == "string" and string.match(displayName, "^|c(%x%x%x%x%x%x%x%x)")
        if embeddedHex and not isSelf then
            tHex = embeddedHex
        end
        displayName = StripColorCodes(displayName)

        if data.PX and strtrim(data.PX) ~= "" and not string.find(displayName, strtrim(data.PX), 1, true) then
            displayName = strtrim(data.PX) .. " " .. displayName
        end
        local titleStr = (data.NT and data.NT ~= "") and ("   |cfffdd663<" .. data.NT .. ">|r") or ""
        dossierFrame.headerName:SetText("|c" .. tHex .. displayName .. "|r" .. titleStr)

        local icBadge = (data.FC == "2") and "|cff81c995[IC]|r" or "|cfff28b82[OOC]|r"
        local wuBadge = ns:GetTargetWalkUpInfo(data)
        local statusBadges = wuBadge and (icBadge .. "   " .. wuBadge) or icBadge

        local racePart = strtrim(data.RA or "")
        local rawClass = strtrim(tostring(data.RC or ""))
        local classPart = ""
        if rawClass ~= "" then
            if isSelf and ns.GetPlayerClassColorCode then
                classPart = "|c" .. ns:GetPlayerClassColorCode() .. StripColorCodes(rawClass) .. "|r"
            elseif string.find(rawClass, "|c", 1, true) then
                classPart = rawClass
            else
                classPart = "|cffe8eaed" .. rawClass .. "|r"
            end
        end
        local raceClass = strtrim((racePart ~= "" and ("|cffe8eaed" .. racePart .. "|r   ") or "") .. classPart)

        local seenStr = ""
        if data.lastSeen and data.lastSeen > 0 then
            seenStr = "     |cff9aa0a6Seen:|r " .. date("%m/%d %H:%M", data.lastSeen)
        end
        local leftMeta = (raceClass ~= "") and (statusBadges .. "     " .. raceClass) or statusBadges
        dossierFrame.vitalsText:SetText(leftMeta .. seenStr)
    end

    if activeSubView == "NOTES" then
        dossierFrame.readerBox:Hide()
        dossierFrame.notesPanel:Show()
        local sHex = ns:GetStandingColorHex(standing)
        dossierFrame.standingBtn:SetText("Standing: |c" .. sHex .. standing .. "|r")
        dossierFrame.standingBtn:SetTone(ns:GetStandingTone(standing))

        if dossierFrame.relEditBox and not dossierFrame.relEditBox:HasFocus() and not dossierFrame.relEditBox.isDirty then
            dossierFrame.relEditBox:SetCleanText(assignedRel)
        end

        local myCharDisplay = (ns.profile and ns.profile.firstName and ns.profile.firstName ~= "") and ns.profile.firstName or (UnitName("player") or "Character")
        if ns.profile and ns.profile.lastName and strtrim(ns.profile.lastName) ~= "" then
            myCharDisplay = myCharDisplay .. " " .. strtrim(ns.profile.lastName)
        end
        dossierFrame.charNoteLabel:SetText("|cff81c995Notes from " .. myCharDisplay .. "|r  |cff9aa0a6(Character-Specific)|r")

        if not dossierFrame.charNoteBox:HasFocus() then
            dossierFrame.charNoteBox:SetCleanText(charNote)
        end
        if not dossierFrame.acctNoteBox:HasFocus() then
            dossierFrame.acctNoteBox:SetCleanText(acctNote)
        end
    else
        if dossierFrame.standingDropdown then dossierFrame.standingDropdown:Hide() end
        dossierFrame.notesPanel:Hide()
        dossierFrame.readerBox:Show()

        if not data or not data.NA then
            dossierFrame.scrollText:SetText("|cff9aa0a6No RP profile loaded for this player. Switch to the Notes tab to keep private notes.|r")
        elseif activeSubView == "ABOUT" then
            dossierFrame.scrollText:SetText(BuildAboutText(data))
        elseif activeSubView == "GLANCES" then
            dossierFrame.scrollText:SetText(BuildGlancesStatusText(data, isSelf))
        else
            dossierFrame.scrollText:SetText(BuildCharacteristicsText(data, isSelf, key))
        end

        local scrollW = dossierFrame.scrollFrame:GetWidth()
        if scrollW and scrollW > 60 then
            dossierFrame.scrollChild:SetWidth(scrollW - 10)
            dossierFrame.scrollText:SetWidth(scrollW - 16)
        end
        local textH = dossierFrame.scrollText:GetStringHeight() or 140
        local viewH = dossierFrame.scrollFrame:GetHeight() or 360
        dossierFrame.scrollChild:SetHeight(math.max(viewH, textH + 28))
        if viewChanged and dossierFrame.scrollFrame.SetVerticalScroll then
            dossierFrame.scrollFrame:SetVerticalScroll(0)
        end
        if dossierFrame.scrollFrame.UpdateScrollChildRect then
            dossierFrame.scrollFrame:UpdateScrollChildRect()
        end
    end
end

function ns:OpenTargetDossier(specificKey)
    if not dossierFrame then ns:InitDossierWindow() end

    local shouldScan = false
    if specificKey and specificKey ~= "" then
        selectedDossierKey = specificKey
        local cached = ResolveProfileRecordForKey(selectedDossierKey)
        local isTargetedUnit = UnitExists("target") and UnitIsPlayer("target") and ns.GetUnitKey and (ns:GetUnitKey("target") == selectedDossierKey)
        if isTargetedUnit or not cached or not cached.NA then
            shouldScan = true
        end
    elseif UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then
        selectedDossierKey = (ns.GetUnitKey and ns:GetUnitKey("target")) or UnitName("target")
        shouldScan = true
    elseif ns.lastInspectedKey then
        selectedDossierKey = ns.lastInspectedKey
        local cached = ResolveProfileRecordForKey(selectedDossierKey)
        if not cached or not cached.NA then
            shouldScan = true
        end
    end

    if shouldScan and selectedDossierKey and ns.RequestUnitMSP then
        ns:RequestUnitMSP(selectedDossierKey, true, true)
    end

    activeSubView = "CHAR"
    lastRenderedKey = nil
    lastRenderedSubView = nil
    if dossierFrame.standingDropdown then dossierFrame.standingDropdown:Hide() end
    dossierFrame:SetScale((ns.db and ns.db.ui and ns.db.ui.scale) or 1.0)
    dossierFrame:Show()
    dossierFrame:Raise()
    ns:RefreshDossierWindow()

    if ns.UpdateControllerBindings then
        ns:UpdateControllerBindings()
    end
    if ns.FocusFirstInScope then
        ns:FocusFirstInScope()
    end
end

function ns:InitDossierWindow()
    if dossierFrame then return end
    local M3 = ns.M3

    dossierFrame = CreateFrame("Frame", "PadRP_DossierWindow", UIParent, "BackdropTemplate")
    ns.dossierFrame = dossierFrame
    dossierFrame:SetSize(656, 524)
    dossierFrame:SetPoint("CENTER", UIParent, "CENTER", 40, -10)
    dossierFrame:SetFrameStrata("DIALOG")
    dossierFrame:SetFrameLevel(40)
    dossierFrame:SetMovable(true)
    dossierFrame:EnableMouse(true)
    dossierFrame:RegisterForDrag("LeftButton")
    dossierFrame:SetScript("OnDragStart", dossierFrame.StartMoving)
    dossierFrame:SetScript("OnDragStop", dossierFrame.StopMovingOrSizing)
    dossierFrame:SetScript("OnHide", function()
        if dossierFrame.standingDropdown then
            dossierFrame.standingDropdown:Hide()
        end

        SaveCurrentNotes()

        if ns.UpdateControllerBindings then
            ns:UpdateControllerBindings()
        end
        if ns.FocusFirstInScope then
            ns:FocusFirstInScope()
        end
    end)

    dossierFrame:SetScript("OnShow", function()
        if ns.UpdateControllerBindings then
            ns:UpdateControllerBindings()
        end
    end)
    ns:ApplySurface(dossierFrame, M3.surfaceDim, M3.primary)
    ns:EnableClipping(dossierFrame)
    dossierFrame:Hide()
    tinsert(UISpecialFrames, "PadRP_DossierWindow")

    local portraitBox = CreateFrame("Frame", nil, dossierFrame, "BackdropTemplate")
    portraitBox:SetSize(50, 50)
    portraitBox:SetPoint("TOPLEFT", 16, -12)
    ns:ApplySurface(portraitBox, M3.surface, M3.primary)
    dossierFrame.portraitBox = portraitBox
    dossierFrame.portraitTex = portraitBox:CreateTexture(nil, "OVERLAY")
    dossierFrame.portraitTex:SetSize(44, 44)
    dossierFrame.portraitTex:SetPoint("CENTER")
    dossierFrame.portraitTex:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    local closeBtn = ns:CreateMaterialButton(dossierFrame, "X", 28, 24, 616, -10, "CORAL", function()
        dossierFrame:Hide()
    end)
    closeBtn:ClearAllPoints()
    closeBtn:SetPoint("TOPRIGHT", dossierFrame, "TOPRIGHT", -14, -10)
    dossierFrame.closeBtn = closeBtn

    dossierFrame.modeBadge = dossierFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dossierFrame.headerName = dossierFrame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    dossierFrame.headerName:SetJustifyH("LEFT")
    dossierFrame.headerName:SetWordWrap(false)

    dossierFrame.vitalsText = dossierFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    dossierFrame.vitalsText:SetJustifyH("LEFT")
    dossierFrame.vitalsText:SetWordWrap(false)

    SetDossierPortraitIcon(nil, nil, false)

    local function SwitchSubView(viewName)
        if activeSubView == "NOTES" then SaveCurrentNotes() end
        if dossierFrame.standingDropdown then dossierFrame.standingDropdown:Hide() end
        activeSubView = viewName
        ns:RefreshDossierWindow()
    end

    dossierFrame.tabChar = ns:CreateMaterialButton(dossierFrame, "Characteristics", 151, 26, 16, -70, "PRIMARY", function()
        SwitchSubView("CHAR")
    end)
    dossierFrame.tabAbout = ns:CreateMaterialButton(dossierFrame, "About (Bio)", 151, 26, 173, -70, nil, function()
        SwitchSubView("ABOUT")
    end)
    dossierFrame.tabGlances = ns:CreateMaterialButton(dossierFrame, "Glances & Status", 151, 26, 330, -70, nil, function()
        SwitchSubView("GLANCES")
    end)
    dossierFrame.tabNotes = ns:CreateMaterialButton(dossierFrame, "Notes", 151, 26, 487, -70, nil, function()
        SwitchSubView("NOTES")
    end)

    local readerBox = CreateFrame("Frame", nil, dossierFrame, "BackdropTemplate")
    readerBox:SetPoint("TOPLEFT", 16, -104)
    readerBox:SetPoint("BOTTOMRIGHT", -16, 16)
    ns:ApplySurface(readerBox, M3.surfaceLow, M3.outline)
    ns:EnableClipping(readerBox)
    dossierFrame.readerBox = readerBox

    local scrollFrame = CreateFrame("ScrollFrame", "PadRP_DossierScrollFrame", readerBox, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 14, -12)
    scrollFrame:SetPoint("BOTTOMRIGHT", -28, 12)
    scrollFrame:EnableMouseWheel(true)
    ns:EnableClipping(scrollFrame)
    dossierFrame.scrollFrame = scrollFrame

    scrollFrame:SetScript("OnMouseWheel", function(self, delta)
        if not delta or delta == 0 then return end
        local cur = self:GetVerticalScroll() or 0
        local maxS = (self.GetVerticalScrollRange and self:GetVerticalScrollRange()) or 0
        local step = (delta > 0) and -56 or 56
        self:SetVerticalScroll(math.max(0, math.min(maxS, cur + step)))
    end)

    local scrollChild = CreateFrame("Frame", nil, scrollFrame)
    scrollChild:SetSize(580, 180)
    scrollFrame:SetScrollChild(scrollChild)
    dossierFrame.scrollChild = scrollChild

    dossierFrame.scrollText = scrollChild:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    dossierFrame.scrollText:SetPoint("TOPLEFT", 0, 0)
    dossierFrame.scrollText:SetWidth(570)
    dossierFrame.scrollText:SetJustifyH("LEFT")
    dossierFrame.scrollText:SetWordWrap(true)
    dossierFrame.scrollText:SetSpacing(3)

    local notesPanel = CreateFrame("Frame", nil, dossierFrame, "BackdropTemplate")
    notesPanel:SetPoint("TOPLEFT", 16, -104)
    notesPanel:SetPoint("BOTTOMRIGHT", -16, 16)
    ns:ApplySurface(notesPanel, M3.surfaceLow, M3.outline)
    ns:EnableClipping(notesPanel)
    notesPanel:Hide()
    dossierFrame.notesPanel = notesPanel

    local standingDropdown = CreateFrame("Frame", "PadRP_DossierStandingDropdown", notesPanel, "BackdropTemplate")
    standingDropdown:SetSize(192, 224)
    standingDropdown:SetFrameStrata("DIALOG")
    standingDropdown:SetFrameLevel(notesPanel:GetFrameLevel() + 30)
    ns:ApplySurface(standingDropdown, M3.surfaceDim, M3.primary)
    ns:EnableClipping(standingDropdown)
    standingDropdown:EnableMouse(true)
    standingDropdown:Hide()
    standingDropdown.rows = {}
    dossierFrame.standingDropdown = standingDropdown

    standingDropdown.Rebuild = function(self)
        for _, r in ipairs(self.rows) do
            r:Hide()
        end
        local options = GetAllStandingsList()
        local curStanding = (selectedDossierKey and EnsureNoteRecord(selectedDossierKey).standing) or "None"
        self:SetHeight(#options * 27 + 12)
        for idx, optName in ipairs(options) do
            local btn = self.rows[idx]
            if not btn then
                btn = ns:CreateMaterialButton(self, "", 176, 24, 8, -6 - (idx - 1) * 27, nil, function(b)
                    ApplyStandingSelection(b.standingValue)
                end)
                btn.label:SetJustifyH("LEFT")
                self.rows[idx] = btn
            end
            btn.standingValue = optName
            local isSel = (string.lower(optName) == string.lower(curStanding))
            local sHex = ns:GetStandingColorHex(optName)
            btn:SetText((isSel and "> " or "  ") .. "|c" .. sHex .. optName .. "|r")
            btn:SetTone(ns:GetStandingTone(optName))
            btn:Show()
        end
    end

    dossierFrame.standingBtn = ns:CreateMaterialButton(notesPanel, "Standing: None", 190, 26, 12, -12, nil, function(self)
        if standingDropdown:IsShown() then
            standingDropdown:Hide()
            if ns.SetControllerFocus then ns:SetControllerFocus(self) end
        else
            standingDropdown:ClearAllPoints()
            standingDropdown:SetPoint("TOPLEFT", self, "BOTTOMLEFT", 0, -2)
            standingDropdown:Rebuild()
            standingDropdown:Show()
            if ns.FocusFirstInScope then ns:FocusFirstInScope() end
        end
    end)

    dossierFrame.relEditBox = ns:CreateMaterialEditBox(notesPanel, nil, "Optional relation label (e.g., Oath-Kin)...", 212, -12, 400, 26, function()
        SaveCurrentNotes()
    end)

    dossierFrame.charNoteLabel = notesPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    dossierFrame.charNoteLabel:SetPoint("TOPLEFT", 12, -50)
    dossierFrame.charNoteLabel:SetText("|cff81c995Notes from " .. (UnitName("player") or "Character") .. "|r  |cff9aa0a6(Character-Specific)|r")

    dossierFrame.charNoteBox = ns:CreateScrollableTextEditor(
        notesPanel,
        "Private RP notes from this character's perspective (e.g., how you met, debts, impressions)...",
        12, -68, 600, 140,
        function() SaveCurrentNotes() end
    )

    local acctLabel = notesPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    acctLabel:SetPoint("TOPLEFT", 12, -220)
    acctLabel:SetText("|cff8ab4f8Account-Wide Notes|r  |cff9aa0a6(Shared across all your characters)|r")

    dossierFrame.acctNoteBox = ns:CreateScrollableTextEditor(
        notesPanel,
        "OOC / Account-wide notes about this player...",
        12, -238, 600, 140,
        function() SaveCurrentNotes() end
    )

    if ConsolePort and ConsolePort.AddInterfaceCursorFrame then
        ConsolePort:AddInterfaceCursorFrame("PadRP_DossierWindow")
    end
end