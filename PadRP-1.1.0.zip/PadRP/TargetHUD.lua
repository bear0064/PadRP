local _, ns = ...

local hudFrame
local ldbObject
local LDBIcon
local fallbackMinimapBtn
local hudDismissedKey = nil
local lastActiveHUDKey = nil

local TOOLTIP_FADE_DURATION = 0.45
local HUD_POLL_INTERVAL = 0.15

local tooltipState = setmetatable({}, { __mode = "k" })
local isDecoratingTooltip = false

local STANDING_COLORS = {
    Ally         = "|cff81c995[ALLY]|r ",
    Friendly     = "|cff81c995[FRIENDLY]|r ",
    Neutral      = "|cff8ab4f8[NEUTRAL]|r ",
    Unfriendly   = "|cfff28b82[UNFRIENDLY]|r ",
    Rival        = "|cfff28b82[RIVAL]|r ",
    Marked       = "|cfffdd663[MARKED]|r ",
}

function ns:EnsureUIDefaults()
    if not ns.db then return end
    ns.db.ui = ns.db.ui or {}
    local ui = ns.db.ui
    if ui.showTargetHUD == nil then ui.showTargetHUD = true end
    if ui.nameplateStatusTags == nil then ui.nameplateStatusTags = true end
    if ui.nameplateStandingCircle == nil then ui.nameplateStandingCircle = true end
end

local function IsToastEnabled(ui)
    if not ui then return false end
    if ui.showTargetHUD ~= nil then
        return ui.showTargetHUD ~= false
    end
    return true
end

local function GetStandingBadgePrefix(standing)
    if not standing or standing == "None" then return "" end
    if STANDING_COLORS[standing] then
        return STANDING_COLORS[standing]
    end
    return "|cfffdd663[" .. string.upper(tostring(standing)) .. "]|r "
end

local function HexToRGB(hex)
    if type(hex) ~= "string" then return nil end
    local clean = hex:gsub("^|c", ""):gsub("^#", "")
    if #clean == 8 then
        clean = clean:sub(3, 8)
    end
    if #clean ~= 6 or not clean:match("^%x%x%x%x%x%x$") then
        return nil
    end
    return tonumber(clean:sub(1, 2), 16) / 255,
           tonumber(clean:sub(3, 4), 16) / 255,
           tonumber(clean:sub(5, 6), 16) / 255
end

local function StripColorCodes(str)
    if not str then return "" end
    local clean = tostring(str):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    return clean
end

local function CleanOOCTooltipText(raw)
    if not raw then return "" end
    local clean = strtrim(StripColorCodes(raw))
    clean = clean:gsub("%[Walk%-Ups:[^%]]*%]", "")
    clean = clean:gsub("%[Walk%-Ups Welcome%]", "")
    clean = clean:gsub("%[Walk%-Ups: Ask First%]", "")
    clean = clean:gsub("%[No Walk%-Ups%]", "")
    clean = clean:gsub("%[Pronouns:[^%]]*%]", "")
    clean = clean:gsub("^%s*[•|%-]+%s*", "")
    clean = clean:gsub("%s*[•|%-]+%s*$", "")
    return strtrim(clean)
end

local function IconPathExists(path)
    if type(GetFileIDFromPath) == "function" then
        local ok, id = pcall(GetFileIDFromPath, path)
        if ok then
            return id ~= nil and id ~= 0
        end
    end
    return true
end

local function IsSentinelOrInvalidID(numId)
    if type(numId) ~= "number" or numId <= 0 then
        return true
    end
    if numId >= 2147483647 then
        return true
    end
    return false
end

local function TruncateTooltipBlock(text, maxChars)
    if type(text) ~= "string" then return "" end
    local clean = strtrim(text)
    if #clean <= maxChars then return clean end
    local cut = string.sub(clean, 1, maxChars)
    local lastSpace = string.match(cut, "^(.*)%s+%S*$")
    if lastSpace and #lastSpace > math.floor(maxChars * 0.6) then
        cut = lastSpace
    end
    return cut .. "... |cff8ab4f8(Dossier for full)|r"
end

local function FormatInlineTexture(texVal, size)
    local px = size or 16
    if type(texVal) == "number" and not IsSentinelOrInvalidID(texVal) then
        return string.format("|T%.0f:%d:%d:0:0:64:64:4:60:4:60|t ", texVal, px, px)
    elseif type(texVal) == "string" then
        local clean = strtrim(texVal)
        local numId = tonumber(clean)
        if numId then
            if IsSentinelOrInvalidID(numId) then
                return ""
            end
            return string.format("|T%.0f:%d:%d:0:0:64:64:4:60:4:60|t ", numId, px, px)
        end
        if clean ~= "" then
            return string.format("|T%s:%d:%d:0:0:64:64:4:60:4:60|t ", clean, px, px)
        end
    end
    return ""
end

local function ResolveCustomPortraitTag(iconVal, size)
    if iconVal == nil or iconVal == false then
        return ""
    end
    local clean = strtrim(tostring(iconVal))
    if clean == "" then
        return ""
    end
    local low = string.lower(clean)
    if low == "nil" or low == "none" or low == "0" then
        return ""
    end

    local directNum = tonumber(clean)
    if directNum and IsSentinelOrInvalidID(directNum) then
        return ""
    end

    local resolved = nil
    if ns.IconPool and type(ns.IconPool.ResolveTexture) == "function" then
        local ok, res = pcall(ns.IconPool.ResolveTexture, ns.IconPool, clean, nil)
        if ok and res and res ~= 134400 then
            local rNum = tonumber(res)
            if not rNum or not IsSentinelOrInvalidID(rNum) then
                resolved = res
            end
        end
    end

    if not resolved and ns.ResolveIconTexture then
        local ok, res = pcall(ns.ResolveIconTexture, ns, clean, nil)
        if ok and res and res ~= 134400 then
            local rNum = tonumber(res)
            if not rNum or not IsSentinelOrInvalidID(rNum) then
                resolved = res
            end
        end
    end

    if not resolved then
        if directNum and not IsSentinelOrInvalidID(directNum) then
            resolved = directNum
        elseif string.find(clean, "\\", 1, true) or string.find(clean, "/", 1, true) then
            if IconPathExists(clean) then
                resolved = clean
            end
        else
            local guess = "Interface\\Icons\\" .. clean
            if IconPathExists(guess) then
                resolved = guess
            end
        end
    end

    return FormatInlineTexture(resolved, size)
end

local function FormatGlanceTooltipLine(rawGlance)
    if type(rawGlance) ~= "string" then return "" end
    local trimmed = strtrim(rawGlance)
    if trimmed == "" then return "" end

    local iconSpec, rest = string.match(trimmed, "^|T([^:|]+):[^|]*|t%s*(.*)$")
    local iconTag
    if iconSpec then
        iconTag = ResolveCustomPortraitTag(iconSpec, 14)
        if iconTag == "" then
            iconTag = "|T134400:14:14:0:0:64:64:4:60:4:60|t "
        end
    else
        iconTag = "|T134400:14:14:0:0:64:64:4:60:4:60|t "
        rest = trimmed
    end

    local cleanRest = strtrim(rest or "")
    local titleOnly = string.match(cleanRest, "^(.-)%s+%-%s+")
    if titleOnly and strtrim(titleOnly) ~= "" then
        return iconTag .. "|cfffdd663" .. strtrim(titleOnly) .. "|r"
    end

    local shortBody = TruncateTooltipBlock(cleanRest, 60)
    return iconTag .. shortBody
end

local function BuildSelfGlanceTooltipLines()
    local lines = {}
    local list = ns.profile and ns.profile.glances
    if type(list) ~= "table" then return lines end

    for idx = 1, math.min(5, #list) do
        local g = list[idx]
        if type(g) == "table" then
            local title = strtrim(StripColorCodes(g.title or ""))
            local detail = strtrim(StripColorCodes(g.text or g.detail or ""))
            if title ~= "" or detail ~= "" then
                local iconTag = ResolveCustomPortraitTag(g.icon, 14)
                if iconTag == "" then
                    iconTag = "|T134400:14:14:0:0:64:64:4:60:4:60|t "
                end
                local label = (title ~= "") and ("|cfffdd663" .. title .. "|r") or TruncateTooltipBlock(detail, 60)
                table.insert(lines, iconTag .. label)
            end
        end
    end
    return lines
end

local function BuildTooltipPortraitTag(iconVal, unit, hasProfile)
    local customTag = ResolveCustomPortraitTag(iconVal, 16)
    if customTag ~= "" then
        return customTag
    end

    if hasProfile and unit and UnitExists(unit) and UnitIsPlayer(unit) then
        local _, classFile = UnitClass(unit)
        local coords = classFile and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[classFile]
        if coords then
            local l = math.floor((coords[1] or 0) * 64 + 0.5)
            local r = math.floor((coords[2] or 1) * 64 + 0.5)
            local t = math.floor((coords[3] or 0) * 64 + 0.5)
            local b = math.floor((coords[4] or 1) * 64 + 0.5)
            return string.format("|TInterface\\TargetingFrame\\UI-Classes-Circles:16:16:0:0:64:64:%d:%d:%d:%d|t ", l, r, t, b)
        end
        return "|T134400:16:16:0:0:64:64:4:60:4:60|t "
    end

    return ""
end

local function BuildProfileSignature(data, standing, hasNote, portraitTag, isSelf)
    local selfGlanceSig = ""
    if isSelf and ns.profile and type(ns.profile.glances) == "table" then
        local parts = {}
        for i = 1, 5 do
            local g = ns.profile.glances[i]
            if type(g) == "table" then
                parts[i] = tostring(g.icon or "") .. ":" .. tostring(g.title or "")
            else
                parts[i] = ""
            end
        end
        selfGlanceSig = table.concat(parts, ";")
    end

    if not data then
        return "NONE|" .. tostring(standing or "") .. "|" .. tostring(hasNote and 1 or 0) .. "|" .. tostring(portraitTag or "") .. "|" .. selfGlanceSig
    end
    return table.concat({
        tostring(data.NA or ""),
        tostring(data.NT or ""),
        tostring(data.FC or ""),
        tostring(data.CU or ""),
        tostring(data.CO or ""),
        tostring(data.PE or ""),
        tostring(standing or ""),
        tostring(hasNote and 1 or 0),
        tostring(portraitTag or ""),
        selfGlanceSig,
    }, "|")
end

local function GetActiveOtherPlayerUnit()
    if UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player") then
        return "target"
    end
    if UnitExists("mouseover") and UnitIsPlayer("mouseover") and not UnitIsUnit("mouseover", "player") then
        return "mouseover"
    end
    return nil
end

local function IsHardTargetedOtherPlayer()
    return UnitExists("target") and UnitIsPlayer("target") and not UnitIsUnit("target", "player")
end

local function CancelHUDFadeOut()
    if not hudFrame then return end
    hudFrame._isFadingOut = false
    hudFrame._fadeRemaining = 0
    hudFrame:SetAlpha(1)
end

local function StartHUDFadeOut(duration)
    if not hudFrame then return end
    if not hudFrame:IsShown() then
        hudFrame._isFadingOut = false
        hudFrame._fadeRemaining = 0
        hudFrame:SetAlpha(1)
        return
    end
    if hudFrame._isFadingOut then
        return
    end
    local fadeLen = tonumber(duration) or TOOLTIP_FADE_DURATION
    if fadeLen <= 0 then
        hudFrame._isFadingOut = false
        hudFrame._fadeRemaining = 0
        hudFrame:SetAlpha(1)
        hudFrame:Hide()
        return
    end
    hudFrame._isFadingOut = true
    hudFrame._fadeDuration = fadeLen
    hudFrame._fadeRemaining = math.max(0.05, fadeLen * (hudFrame:GetAlpha() or 1))
end

local function UpdateHUDFrame(self, elapsed)
    if self._isFadingOut then
        local rem = (self._fadeRemaining or 0) - (elapsed or 0)
        local dur = self._fadeDuration or TOOLTIP_FADE_DURATION
        if rem <= 0 or dur <= 0 then
            self._isFadingOut = false
            self._fadeRemaining = 0
            self:SetAlpha(1)
            self:Hide()
            return
        end
        self._fadeRemaining = rem
        self:SetAlpha(math.max(0, math.min(1, rem / dur)))
        return
    end

    if not self:IsShown() then return end
    self._pollElapsed = (self._pollElapsed or 0) + (elapsed or 0)
    if self._pollElapsed < HUD_POLL_INTERVAL then return end
    self._pollElapsed = 0

    local activeUnit = GetActiveOtherPlayerUnit()
    if not activeUnit then
        lastActiveHUDKey = nil
        hudDismissedKey = nil
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        if ns.currentFocus == self and ns.SetControllerFocus then
            ns:SetControllerFocus(nil)
        end
    end
end

local function RegisterHUDWithConsolePort()
    if not hudFrame or not ConsolePort then return end
    pcall(function()
        hudFrame:SetAttribute("UIPanelLayout-enabled", true)
        hudFrame:SetAttribute("UIPanelLayout-area", "center")
        if ConsolePort.AddInterfaceCursorFrame then
            ConsolePort:AddInterfaceCursorFrame("PadRP_TargetHUD")
        end
        if ConsolePort.RegisterFrame then
            ConsolePort:RegisterFrame(hudFrame)
        end
    end)
end

function ns:DismissTargetHUDFocus()
    if hudFrame then
        hudDismissedKey = hudFrame.inspectedKey or "__ACTIVE__"
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
    end
    if ns.SetControllerFocus then
        ns:SetControllerFocus(nil)
    end
    if ns.UpdateControllerBindings then
        ns:UpdateControllerBindings()
    end
end

function ns:GetNoteInfo(key)
    if not key or not ns.db or not ns.db.notes then
        return "None", "", "", false
    end
    local rec = ns.db.notes[key]
    if type(rec) ~= "table" then
        return "None", "", "", false
    end

    local charKey = ns.GetPlayerCharKey and ns:GetPlayerCharKey() or "Default"
    local charNote = (type(rec.charNotes) == "table" and rec.charNotes[charKey]) or ""
    local acctNote = rec.accountNote
    if acctNote == nil then
        acctNote = rec.note or ""
    end

    local hasNote = (strtrim(charNote) ~= "") or (strtrim(acctNote) ~= "")
    return rec.standing or "None", charNote, acctNote, hasNote
end

function ns:HasSavedNote(key)
    local _, _, _, hasNote = ns:GetNoteInfo(key)
    return hasNote
end

local function HandleMinimapClick(button)
    if button == "RightButton" then
        ns:PlayUISound()
        local isIC = ns:ToggleICOOC()
        print("|cff8ab4f8[PadRP]|r Status: " .. (isIC and "|cff81c995In Character (IC)|r" or "|cfff28b82Out of Character (OOC)|r"))
        if ns.RefreshControllerUI then ns:RefreshControllerUI() end
        if ns.RefreshMinimapButton then ns:RefreshMinimapButton() end
    elseif button == "MiddleButton" then
        ns:QuickThankAction()
    else
        if ns.ToggleMainFrame then ns:ToggleMainFrame() end
    end
end

local function PopulateMinimapTooltip(tooltip)
    tooltip:AddLine("PadRP - Material Dark RP Suite", 0.54, 0.71, 0.97)
    local status = (ns.profile and ns.profile.isIC) and "|cff81c995In Character (IC)|r" or "|cfff28b82Out of Character (OOC)|r"
    tooltip:AddLine("Status: " .. status, 1, 1, 1)
    tooltip:AddLine("Walk-Ups: |cfffdd663" .. ns:GetWalkUpLabel() .. "|r", 1, 1, 1)
    tooltip:AddLine("Currently: |cffe8eaed" .. ((ns.profile and ns.profile.currently) or "None") .. "|r", 0.8, 0.8, 0.8)
    tooltip:AddLine(" ")
    tooltip:AddLine("|cff8ab4f8Left-Click:|r Open PadRP Menu", 0.75, 0.8, 0.88)
    tooltip:AddLine("|cff8ab4f8Right-Click:|r Toggle IC / OOC", 0.75, 0.8, 0.88)
    tooltip:AddLine("|cff8ab4f8Middle-Click:|r Quick-Thank Helper", 0.75, 0.8, 0.88)
    tooltip:AddLine("|cff8ab4f8Drag:|r Move Around Minimap", 0.75, 0.8, 0.88)
end

local function DecorateUnitTooltipInternal(tooltip, tooltipData, skipRequest)
    if not tooltip or (tooltip.IsForbidden and tooltip:IsForbidden()) then return end
    if not ns.db or not ns.db.ui or not ns.db.ui.rpTooltip then return end
    if InCombatLockdown() and ns.db.ui.hideInCombat then return end

    local _, unit = tooltip:GetUnit()
    if (not unit or not UnitExists(unit)) and tooltipData and tooltipData.guid and UnitTokenFromGUID then
        unit = UnitTokenFromGUID(tooltipData.guid)
    end
    if (not unit or not UnitExists(unit)) and UnitExists("mouseover") then
        unit = "mouseover"
    end
    if not unit or not UnitExists(unit) or not UnitIsPlayer(unit) then return end

    local isSelf = UnitIsUnit(unit, "player")
    if not skipRequest and not isSelf and ns.RequestUnitMSP then
        ns:RequestUnitMSP(unit, false, false, true)
    end

    local data, key = ns:GetCachedMSP(unit)
    local standing, charNote, acctNote, hasNote = ns:GetNoteInfo(key)
    local hasProfile = (data and data.NA and data.NA ~= "") or isSelf or hasNote or (standing ~= "None")

    if (not data or not data.NA or data.NA == "") and not hasNote and standing == "None" and not isSelf then
        return
    end

    local customIcon = isSelf and (ns.profile and ns.profile.icon) or (data and data.IC)
    local portraitTag = BuildTooltipPortraitTag(customIcon, unit, hasProfile)
    local signature = BuildProfileSignature(data, standing, hasNote, portraitTag, isSelf)

    local state = tooltipState[tooltip]
    if state and state.taggedKey == key and state.portraitTag == portraitTag and state.signature == signature then
        return
    end

    local _, classFile = UnitClass(unit)
    local r, g, b = 0.54, 0.71, 0.97
    if classFile and RAID_CLASS_COLORS and RAID_CLASS_COLORS[classFile] then
        r, g, b = RAID_CLASS_COLORS[classFile].r, RAID_CLASS_COLORS[classFile].g, RAID_CLASS_COLORS[classFile].b
    end
    if isSelf and ns.GetPlayerClassColorCode then
        local cr, cg, cb = HexToRGB(ns:GetPlayerClassColorCode())
        if cr then r, g, b = cr, cg, cb end
    end

    local standingTag = GetStandingBadgePrefix(standing)
    local noteIcon = hasNote and " |TInterface\\Icons\\INV_Misc_Note_01:14:14:0:0:64:64:4:60:4:60|t" or ""

    local tName = tooltip:GetName()
    local line1 = tName and _G[tName .. "TextLeft1"]

    if data and data.NA and data.NA ~= "" then
        local isIC = (data.FC == "2")
        local icFlag = isIC and "|cff81c995[IC]|r" or "|cfff28b82[OOC]|r"
        local wuBadge = ns:GetTargetWalkUpInfo(data)

        local displayName = StripColorCodes(data.NA)
        if data.PX and strtrim(data.PX) ~= "" and not string.find(displayName, strtrim(data.PX), 1, true) then
            displayName = strtrim(data.PX) .. " " .. displayName
        end

        if line1 then
            local rightBadges = wuBadge and (icFlag .. " " .. wuBadge) or icFlag
            line1:SetText(portraitTag .. standingTag .. displayName .. "  " .. rightBadges .. noteIcon)
            line1:SetTextColor(r, g, b)
        end

        if data.NT and data.NT ~= "" then
            tooltip:AddLine("< " .. data.NT .. " >", 0.99, 0.84, 0.39, true)
        end

        local raceClass = strtrim((data.RA or "") .. " " .. (data.RC and StripColorCodes(data.RC) or ""))
        if raceClass ~= "" then
            tooltip:AddLine(raceClass, r, g, b, false)
        end
        if data.NH and data.NH ~= "" then
            tooltip:AddLine("House / Clan: |cfffdd663" .. data.NH .. "|r", 0.80, 0.84, 0.90, false)
        end
        if data.MO and data.MO ~= "" then
            tooltip:AddLine("\"" .. data.MO .. "\"", 0.72, 0.78, 0.86, true)
        end

        local cuVal = (isSelf and ns.profile and ns.profile.currently) or data.CU
        if cuVal and strtrim(StripColorCodes(cuVal)) ~= "" then
            tooltip:AddLine(" ")
            tooltip:AddLine("Currently", 1.0, 1.0, 1.0, false)
            tooltip:AddLine(TruncateTooltipBlock(StripColorCodes(cuVal), 160), 0.99, 0.84, 0.39, true)
        end

        local oocRaw = (isSelf and ns.profile and (ns.profile.oocNotes or ns.profile.oocInfo)) or data.CO
        local oocClean = TruncateTooltipBlock(CleanOOCTooltipText(oocRaw), 220)
        local oocBlock = {}
        if oocClean ~= "" then
            table.insert(oocBlock, oocClean)
        end
        if isSelf and ns.profile then
            local lgbtqText = (ns.profile.lgbtqFriendly ~= false) and "|cff81c995Yes|r" or "|cff9aa0a6No|r"
            local erpText = ns.profile.erpFriendly and "|cfffdd663Yes|r" or "|cff9aa0a6No|r"
            local mdniText = ns.profile.mdni and "|cfff28b82Yes|r" or "|cff9aa0a6No|r"
            table.insert(oocBlock, "|cff9aa0a6LGBTQIA2S+ friendly:|r " .. lgbtqText)
            table.insert(oocBlock, "|cff9aa0a6ERP:|r " .. erpText)
            table.insert(oocBlock, "|cff9aa0a6MDNI:|r " .. mdniText)
        end
        if #oocBlock > 0 then
            tooltip:AddLine(" ")
            tooltip:AddLine("Other information (OOC)", 1.0, 1.0, 1.0, false)
            tooltip:AddLine(table.concat(oocBlock, "\n"), 0.99, 0.84, 0.39, true)
        end

        local glanceLines = isSelf and BuildSelfGlanceTooltipLines() or {}
        if #glanceLines == 0 then
            local glances = ns:ParseGlances(data.PE)
            for idx = 1, math.min(5, #glances) do
                local glanceLine = FormatGlanceTooltipLine(glances[idx])
                if glanceLine ~= "" then
                    table.insert(glanceLines, glanceLine)
                end
            end
        end
        if #glanceLines > 0 then
            tooltip:AddLine(" ")
            tooltip:AddLine("At First Glance", 0.54, 0.71, 0.97, false)
            for _, gLine in ipairs(glanceLines) do
                tooltip:AddLine(gLine, 0.85, 0.88, 0.92, false)
            end
        end
    elseif line1 then
        local rawName = UnitName(unit) or key or "Player"
        line1:SetText(portraitTag .. standingTag .. rawName .. noteIcon)
        line1:SetTextColor(r, g, b)
    end

    if hasNote then
        local preview = (strtrim(charNote) ~= "") and strtrim(charNote) or strtrim(acctNote)
        preview = string.gsub(preview, "[\r\n]+", " ")
        if #preview > 90 then
            preview = string.sub(preview, 1, 87) .. "..."
        end
        tooltip:AddLine(" ")
        tooltip:AddLine("|TInterface\\Icons\\INV_Misc_Note_01:13:13:0:0:64:64:4:60:4:60|t |cff81c995Note:|r " .. preview, 0.85, 0.90, 0.86, true)
    end

    if tooltip.SetClampedToScreen then
        tooltip:SetClampedToScreen(true)
    end
    tooltipState[tooltip] = { taggedKey = key, portraitTag = portraitTag, signature = signature }
    tooltip:Show()
end

local function DecorateUnitTooltip(tooltip, tooltipData, skipRequest)
    if isDecoratingTooltip then return end
    isDecoratingTooltip = true
    pcall(DecorateUnitTooltipInternal, tooltip, tooltipData, skipRequest)
    isDecoratingTooltip = false
end

function ns:RefreshUnitTooltipNow()
    if InCombatLockdown() or isDecoratingTooltip then return end
    if GameTooltip and GameTooltip:IsShown() and UnitExists("mouseover") and UnitIsPlayer("mouseover") then
        local _, currentUnit = GameTooltip:GetUnit()
        if currentUnit and UnitIsUnit(currentUnit, "mouseover") then
            DecorateUnitTooltip(GameTooltip, nil, true)
        end
    end
end

local function InitTooltipHook()
    if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
        pcall(function()
            TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Unit, function(tooltip, data)
                if tooltip == GameTooltip then
                    DecorateUnitTooltip(tooltip, data, false)
                end
            end)
        end)
    end

    if GameTooltip and GameTooltip.HookScript then
        pcall(function()
            GameTooltip:HookScript("OnTooltipSetUnit", function(tooltip)
                DecorateUnitTooltip(tooltip, nil, false)
            end)
        end)
    end

    if GameTooltip and GameTooltip.HookScript then
        pcall(function()
            GameTooltip:HookScript("OnTooltipCleared", function(self)
                tooltipState[self] = nil
                if not IsHardTargetedOtherPlayer() and ns.RefreshTargetHUD then
                    ns:RefreshTargetHUD()
                end
            end)
            GameTooltip:HookScript("OnHide", function(self)
                tooltipState[self] = nil
                if not IsHardTargetedOtherPlayer() and ns.RefreshTargetHUD then
                    ns:RefreshTargetHUD()
                end
            end)
        end)
    end
end

function ns:RefreshMinimapButton()
    if not ns.db or not ns.db.ui then return end
    ns.db.ui.minimapIcon = ns.db.ui.minimapIcon or { hide = false, minimapPos = 215 }
    local shouldShow = (ns.db.ui.showMinimap ~= false)
    local isIC = ns.profile and ns.profile.isIC

    if LDBIcon then
        if fallbackMinimapBtn then fallbackMinimapBtn:Hide() end
        ns.db.ui.minimapIcon.hide = not shouldShow
        if LDBIcon.Refresh then LDBIcon:Refresh("PadRP", ns.db.ui.minimapIcon) end
        if shouldShow then LDBIcon:Show("PadRP") else LDBIcon:Hide("PadRP") end

        local btn = LDBIcon:GetMinimapButton("PadRP")
        if btn and btn.icon then
            if isIC then btn.icon:SetVertexColor(0.55, 1.0, 0.70) else btn.icon:SetVertexColor(1.0, 0.55, 0.55) end
        end
    elseif fallbackMinimapBtn then
        if not shouldShow then fallbackMinimapBtn:Hide(); return end
        fallbackMinimapBtn:Show()
        local angle = math.rad(ns.db.ui.minimapIcon.minimapPos or 215)
        local radius = (Minimap:GetWidth() / 2) + 8
        fallbackMinimapBtn:ClearAllPoints()
        fallbackMinimapBtn:SetPoint("CENTER", Minimap, "CENTER", math.cos(angle) * radius, math.sin(angle) * radius)
        if isIC then fallbackMinimapBtn:SetBackdropBorderColor(0.51, 0.79, 0.58, 1)
        else fallbackMinimapBtn:SetBackdropBorderColor(0.95, 0.55, 0.51, 1) end
    end
end

local function TryRegisterLDBIcon()
    if LDBIcon then return true end
    local LibStub = _G.LibStub
    local LDB = LibStub and LibStub("LibDataBroker-1.1", true)
    local iconLib = LibStub and LibStub("LibDBIcon-1.0", true)
    if not LDB or not iconLib then return false end

    LDBIcon = iconLib
    ldbObject = (LDB.GetDataObjectByName and LDB:GetDataObjectByName("PadRP")) or LDB:NewDataObject("PadRP", {
        type = "launcher",
        text = "PadRP",
        icon = "Interface\\Icons\\INV_Misc_Book_09",
        OnClick = function(_, button) HandleMinimapClick(button) end,
        OnTooltipShow = function(tooltip) PopulateMinimapTooltip(tooltip) end,
    })

    if not LDBIcon.IsRegistered or not LDBIcon:IsRegistered("PadRP") then
        LDBIcon:Register("PadRP", ldbObject, ns.db.ui.minimapIcon)
    end
    ns:RefreshMinimapButton()
    return true
end

local function InitMinimapButton()
    ns.db.ui.minimapIcon = ns.db.ui.minimapIcon or { hide = not ns.db.ui.showMinimap, minimapPos = 215 }
    ns.db.ui.minimapIcon.hide = not ns.db.ui.showMinimap
    if TryRegisterLDBIcon() then return end

    if Minimap and not fallbackMinimapBtn then
        fallbackMinimapBtn = CreateFrame("Button", "PadRP_FallbackMinimapButton", Minimap, "BackdropTemplate")
        fallbackMinimapBtn:SetSize(32, 32)
        fallbackMinimapBtn:SetFrameStrata("MEDIUM")
        fallbackMinimapBtn:SetFrameLevel(8)
        fallbackMinimapBtn:RegisterForClicks("AnyUp")
        fallbackMinimapBtn:RegisterForDrag("LeftButton")
        fallbackMinimapBtn:SetBackdrop({
            bgFile   = "Interface\\Buttons\\WHITE8x8",
            edgeFile = "Interface\\Buttons\\WHITE8x8",
            edgeSize = 2,
            insets   = { left = 2, right = 2, top = 2, bottom = 2 },
        })
        fallbackMinimapBtn:SetBackdropColor(0.08, 0.10, 0.13, 0.96)
        local icon = fallbackMinimapBtn:CreateTexture(nil, "ARTWORK")
        icon:SetSize(22, 22)
        icon:SetPoint("CENTER")
        icon:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
        icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
        fallbackMinimapBtn:SetScript("OnDragStart", function(self)
            self:SetScript("OnUpdate", function()
                local mx, my = Minimap:GetCenter()
                local cx, cy = GetCursorPosition()
                local scale = Minimap:GetEffectiveScale()
                ns.db.ui.minimapIcon.minimapPos = math.deg(math.atan2((cy / scale) - my, (cx / scale) - mx))
                ns:RefreshMinimapButton()
            end)
        end)
        fallbackMinimapBtn:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
        fallbackMinimapBtn:SetScript("OnClick", function(_, button) HandleMinimapClick(button) end)
        fallbackMinimapBtn:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            PopulateMinimapTooltip(GameTooltip)
            GameTooltip:Show()
        end)
        fallbackMinimapBtn:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    ns:RefreshMinimapButton()
    if C_Timer and C_Timer.After then
        C_Timer.After(2.0, function() TryRegisterLDBIcon() end)
    end
end

function ns:ResetMinimapButton()
    if not ns.db or not ns.db.ui then return end
    ns.db.ui.showMinimap = true
    ns.db.ui.minimapIcon = ns.db.ui.minimapIcon or {}
    ns.db.ui.minimapIcon.hide = false
    ns.db.ui.minimapIcon.minimapPos = 215
    TryRegisterLDBIcon()
    ns:RefreshMinimapButton()
    if ns.RefreshControllerUI then ns:RefreshControllerUI() end
end

local function SyncHUDFocusState(shouldShow, activeKey)
    if not hudFrame then return end
    local modalOpen = (ns.mainFrame and ns.mainFrame:IsShown()) or (ns.dossierFrame and ns.dossierFrame:IsShown())
    local curKey = activeKey or "__ACTIVE__"
    if hudDismissedKey and hudDismissedKey ~= curKey then
        hudDismissedKey = nil
    end

    if shouldShow and hudDismissedKey == curKey then
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        if ns.currentFocus == hudFrame and ns.SetControllerFocus then
            ns:SetControllerFocus(nil)
        end
        if ns.UpdateControllerBindings then
            ns:UpdateControllerBindings()
        end
        return
    end

    local shouldAutoFocus = shouldShow and IsHardTargetedOtherPlayer() and not modalOpen

    if shouldAutoFocus then
        RegisterHUDWithConsolePort()
        if ns.SetControllerFocus then
            ns:SetControllerFocus(hudFrame)
        end
        if ns.UpdateControllerBindings then
            ns:UpdateControllerBindings()
        end
    elseif ns.currentFocus == hudFrame then
        if ns.SetControllerFocus then
            ns:SetControllerFocus(nil)
        end
        if ns.UpdateControllerBindings then
            ns:UpdateControllerBindings()
        end
        if not shouldShow then
            StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        end
    elseif not shouldShow then
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
    end
end

function ns:RefreshTargetHUD()
    if not hudFrame then return end
    ns:EnsureUIDefaults()
    if not ns.db or not IsToastEnabled(ns.db.ui) then
        lastActiveHUDKey = nil
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        SyncHUDFocusState(false)
        return
    end
    if ns.db.ui.hideInCombat and InCombatLockdown() then
        lastActiveHUDKey = nil
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        SyncHUDFocusState(false)
        return
    end

    local activeUnit = GetActiveOtherPlayerUnit()
    if not activeUnit then
        hudDismissedKey = nil
        lastActiveHUDKey = nil
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        SyncHUDFocusState(false)
        return
    end

    local data, activeKey = ns:GetCachedMSP(activeUnit)
    local resolvedKey = activeKey or UnitGUID(activeUnit) or UnitName(activeUnit) or "__ACTIVE__"
    if resolvedKey ~= lastActiveHUDKey then
        lastActiveHUDKey = resolvedKey
        hudDismissedKey = nil
        CancelHUDFadeOut()
    end

    if ns.db.ui.hudOnlyRP and (not data or not data.NA) then
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        SyncHUDFocusState(false, resolvedKey)
        return
    end

    if hudDismissedKey and hudDismissedKey == resolvedKey then
        StartHUDFadeOut(TOOLTIP_FADE_DURATION)
        SyncHUDFocusState(false, resolvedKey)
        return
    end

    local _, tClass = UnitClass(activeUnit)
    local tHex = (tClass and RAID_CLASS_COLORS and RAID_CLASS_COLORS[tClass] and RAID_CLASS_COLORS[tClass].colorStr) or "ff8ab4f8"
    local rawName = UnitName(activeUnit) or "Unknown"
    local standing, _, _, hasNote = ns:GetNoteInfo(activeKey)
    local standingTag = GetStandingBadgePrefix(standing)
    local assignedRel = activeKey and ns.GetAssignedRelationship and ns:GetAssignedRelationship(activeKey) or ""
    local relTag = (assignedRel ~= "") and ("  |cfffdd663[" .. assignedRel .. "]|r") or ""
    local noteTag = hasNote and " |TInterface\\Icons\\INV_Misc_Note_01:13:13:0:0:64:64:4:60:4:60|t" or ""

    if data and data.NA and data.NA ~= "" then
        local cleanNA = StripColorCodes(data.NA)
        local titleStr = (data.NT and data.NT ~= "") and ("  |cfffdd663<" .. data.NT .. ">|r") or ""
        hudFrame.nameText:SetText(standingTag .. "|c" .. tHex .. cleanNA .. "|r" .. titleStr .. relTag .. noteTag)
        local isIC = (data.FC == "2")
        local icDot = isIC and "|cff81c995[IC]|r" or "|cfff28b82[OOC]|r"
        local wuBadge = ns:GetTargetWalkUpInfo(data)
        local prefixBadges = wuBadge and (icDot .. " " .. wuBadge) or icDot
        local cuStr = (data.CU and data.CU ~= "") and StripColorCodes(data.CU) or "|cff9aa0a6Focus / Click to open Dossier|r"
        hudFrame.subText:SetText(prefixBadges .. "  |cffe8eaed" .. cuStr .. "|r")
        hudFrame.hintText:SetText("|cff81c995Focus / Click to Open Dossier|r")
        hudFrame.accentBar:SetColorTexture(isIC and 0.51 or 0.95, isIC and 0.79 or 0.55, isIC and 0.58 or 0.51, 1)
    else
        hudFrame.nameText:SetText(standingTag .. "|c" .. tHex .. rawName .. "|r" .. relTag .. noteTag)
        hudFrame.subText:SetText("|cff9aa0a6Standard Player (No RP Profile Cached)|r")
        hudFrame.hintText:SetText("Focus / Click to Open Dossier")
        hudFrame.accentBar:SetColorTexture(0.35, 0.39, 0.46, 0.65)
    end

    CancelHUDFadeOut()
    hudFrame.inspectedKey = activeKey
    hudFrame:SetScale(ns.db.ui.scale or 1.0)
    hudFrame:Show()
    SyncHUDFocusState(true, resolvedKey)
end

function ns:InitTargetHUD()
    ns:EnsureUIDefaults()
    InitMinimapButton()
    InitTooltipHook()

    hudFrame = CreateFrame("Button", "PadRP_TargetHUD", UIParent, "BackdropTemplate")
    ns.hudFrame = hudFrame
    hudFrame:SetSize(430, 62)
    hudFrame:SetPoint("TOP", UIParent, "TOP", 0, -44)
    hudFrame:SetMovable(true)
    hudFrame:EnableMouse(true)
    hudFrame:RegisterForClicks("LeftButtonUp")
    hudFrame:RegisterForDrag("LeftButton")
    hudFrame:SetScript("OnDragStart", hudFrame.StartMoving)
    hudFrame:SetScript("OnDragStop", hudFrame.StopMovingOrSizing)
    hudFrame:SetScript("OnUpdate", UpdateHUDFrame)
    hudFrame:Hide()

    hudFrame:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
        insets   = { left = 1, right = 1, top = 1, bottom = 1 },
    })
    hudFrame:SetBackdropColor(0.08, 0.10, 0.13, 0.96)
    hudFrame:SetBackdropBorderColor(0.20, 0.24, 0.31, 0.85)

    hudFrame.accentBar = hudFrame:CreateTexture(nil, "OVERLAY")
    hudFrame.accentBar:SetHeight(3)
    hudFrame.accentBar:SetPoint("BOTTOMLEFT", 1, 1)
    hudFrame.accentBar:SetPoint("BOTTOMRIGHT", -1, 1)
    hudFrame.accentBar:SetColorTexture(0.54, 0.71, 0.97, 1)

    hudFrame.nameText = hudFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hudFrame.nameText:SetPoint("TOPLEFT", 14, -10)
    hudFrame.nameText:SetWidth(402)
    hudFrame.nameText:SetJustifyH("LEFT")
    hudFrame.nameText:SetWordWrap(false)

    hudFrame.subText = hudFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    hudFrame.subText:SetPoint("TOPLEFT", 14, -27)
    hudFrame.subText:SetWidth(402)
    hudFrame.subText:SetJustifyH("LEFT")
    hudFrame.subText:SetWordWrap(false)

    hudFrame.hintText = hudFrame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hudFrame.hintText:SetPoint("BOTTOMRIGHT", -12, 7)

    hudFrame:SetScript("OnEnter", function(self)
        self:SetBackdropBorderColor(0.54, 0.71, 0.97, 1.0)
        RegisterHUDWithConsolePort()
    end)
    hudFrame:SetScript("OnLeave", function(self)
        self:SetBackdropBorderColor(0.20, 0.24, 0.31, 0.85)
    end)
    hudFrame:SetScript("OnClick", function(self)
        if ns.OpenTargetDossier then
            ns:OpenTargetDossier(self.inspectedKey)
        end
    end)

    if ns.RegisterFocusable then
        ns:RegisterFocusable(hudFrame, function(self)
            if ns.OpenTargetDossier then
                ns:OpenTargetDossier(self.inspectedKey)
            end
        end, function(self, isFocused)
            if isFocused then
                self:SetBackdropBorderColor(0.54, 0.71, 0.97, 1.0)
            else
                self:SetBackdropBorderColor(0.20, 0.24, 0.31, 0.85)
            end
        end)
    end

    RegisterHUDWithConsolePort()

    hudFrame:RegisterEvent("PLAYER_REGEN_DISABLED")
    hudFrame:RegisterEvent("PLAYER_REGEN_ENABLED")
    hudFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
    hudFrame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")
    hudFrame:RegisterEvent("CURSOR_CHANGED")
    hudFrame:SetScript("OnEvent", function() ns:RefreshTargetHUD() end)

    ns:CreateBindButton("PadRP_InspectTargetButton", function()
        if ns.OpenTargetDossier then
            ns:OpenTargetDossier(hudFrame and hudFrame.inspectedKey or ns.lastInspectedKey)
        end
    end)
end